package edu.afit.csce593.smallworld.model;

public class Item {

}