package smallworld.model;

public class Item {

}