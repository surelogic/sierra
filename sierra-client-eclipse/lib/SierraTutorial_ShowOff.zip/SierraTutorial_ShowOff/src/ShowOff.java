public class ShowOff {

    /**
     * A simple main program to demonstrate the {@link #box(Object)} method.
     * 
     * @param args
     *            unused.
     */
    public static void main(String[] args) {
        box(new String("hello"));
        box(null);
    }

    /**
     * Prints the passed object to {@link System#out} with a text box around it.
     * 
     * @param o
     *            the object to show, may be <code>null</code>.
     */
    public static void box(Object o) {
        /*
         * If the object is null then we want to show null.
         */
        if (o == null) {
            System.out.println("null");
        }
        /*
         * Let's do a fancy "box" output for our object.
         */
        StringBuffer b = new StringBuffer(o.toString());
        b.append(" --");
        b.insert(0, "-- ");
        StringBuffer line = new StringBuffer();
        for (int i = 0; i < b.length(); i++)
            line.append("-");
        System.out.println(line.toString());
        System.out.println(b.toString());
        System.out.println(line.toString());
    }
}
